-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 07, 2019 at 05:31 AM
-- Server version: 5.6.43-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `procurement_sys`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `type` enum('Administrator','Vendor','Manager') DEFAULT 'Administrator',
  `first_name` varchar(200) DEFAULT NULL,
  `last_name` varchar(200) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `contact_person` varchar(200) NOT NULL,
  `gender` enum('F','M') DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `is_deleted` enum('1','0') NOT NULL DEFAULT '0' COMMENT '1=Delete, 0=Not Delete',
  `created_date` datetime NOT NULL,
  `status` enum('1','0') NOT NULL COMMENT '1=Enabled,0=Disabled',
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `type`, `first_name`, `last_name`, `dob`, `contact_person`, `gender`, `email`, `mobile_number`, `address`, `password`, `is_deleted`, `created_date`, `status`, `created_by`, `modified_by`, `modified_date`) VALUES
(1, NULL, 'Administrator', 'p systems', 'administartor', '2016-12-23', '', 'M', 'administrator@gmail.com', 0, '', 'ab10ecd36ff8beeda952df46c216065f', '0', '2019-06-28 00:00:00', '1', 0, 0, '0000-00-00 00:00:00'),
(4, 'vendoruser', 'Vendor', 'vendor name', NULL, NULL, 'vdsss', NULL, 'vendor@gmail.com', 9638527410, 'aasdf asdfs afas fasdf dsf', '21eee4b34b6b9f69f93dde34fd1a6ea2', '0', '0000-00-00 00:00:00', '1', 0, 0, '0000-00-00 00:00:00'),
(5, 'asdfasdf', 'Vendor', 'asdfasdf', NULL, NULL, 'dfsadffsad', NULL, 'sdfasdf@gmail.com', 232323, 'afasdfsfdadf', '21eee4b34b6b9f69f93dde34fd1a6ea2', '0', '0000-00-00 00:00:00', '1', 0, 0, '0000-00-00 00:00:00'),
(6, 'vendor', 'Vendor', 'vendor1', NULL, NULL, '9879879876', NULL, 'vendor1@gmail.com', 9879879879, 'hjjjjj', '5422c2c0a64354ea3758e6302f03ad65', '0', '0000-00-00 00:00:00', '1', 0, 0, '0000-00-00 00:00:00'),
(7, 'vendor', 'Vendor', 'vendor', NULL, NULL, 'vendor', NULL, 'v@vendor.com', 1234567890, 'vendor', 'd63ccb55b25602e4649746be3c6f5807', '0', '0000-00-00 00:00:00', '1', 0, 0, '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
