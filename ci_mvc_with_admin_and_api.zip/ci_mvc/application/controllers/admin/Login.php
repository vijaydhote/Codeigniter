<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
	public function __construct() {
		parent::__construct();		
		$this->load->model('admin_model');
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button>', '</div>');
	}
	
	/*public function index(){
		#title
		$data['title'] = 'Coming Soon';
		$data['index'] = random_string('nozero', 4);
		$data['page'] = $this->uri->segment(1);
		
		#Load view template.
		$this->load->view('includes/header', $data);
		$this->load->view('comming_soon');
		$this->load->view('includes/footer');
	
	}*/
	
	#Member login
	 public function index()
	{
		#title
		$data['title'] = 'Admin Login';
		$data['page'] = $this->uri->segment(1);
		#Set form validation rules.
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
		
		if($this->form_validation->run() == FALSE) {
			#load page view
			$this->load->view('admin/login', $data);
		} else {
			$result = $this->process();
			if($result == true) {
				redirect('admin-dashboard');
			} else {
				#load page view
				$this->load->view('admin/login', $data);
			}
		}
	} 
	
	public function process() {
		#grab user input.
		$email = $this->security->xss_clean($this->input->post('email'));
		$password = $this->security->xss_clean($this->input->post('password'));
		$password = $this->commonfunctions->password($password);
		
		$data = array('*');
		$where = array(
			'email' => $email,
			'password' => $password,
			'is_deleted' => '0'
		);
		$login_query = " SELECT id, type, first_name, last_name, email, is_deleted, status FROM tbl_users WHERE email='".$email."' AND password = '".$password."' AND is_deleted = '0' AND type = 'Admin' ";
		$userArr = $this->admin_model->selectQuery($login_query);
		if(count($userArr) > 0) {
			$userArr = $userArr[0];
			$this->session->set_userdata('admin', $userArr);
			redirect('admin-dashboard', 'refresh');
		} else {
			$this->commonfunctions->setFlashMessage('Invalid login Email or Password, please try again!', 'danger');
			return false;
		}
	}
	
	public function forget()
	{
		#title
		$data['title'] = 'Forget password';
		$data['index'] = random_string('nozero', 4);
		$data['page'] = $this->uri->segment(1);
		
		#load page view
		$this->load->view('includes/header', $data);
		$this->load->view('forget_password');
		$this->load->view('includes/footer');
	} 
	
	#Member login
	public function forgetPass()
	{
		#title
		$data['title'] = 'Forget password';
		$data['index'] = random_string('nozero', 4);
		$data['page'] = $this->uri->segment(1);
		
		#Set form validation rules.
		$this->form_validation->set_rules('userid_email', 'UserID OR Email', 'trim|required');
		if($this->form_validation->run() == FALSE) {
			#load page view
			$this->load->view('includes/header', $data);
			$this->load->view('forget_password');
			$this->load->view('includes/footer');
		} else {
			$userid_email = $this->security->xss_clean($this->input->post('userid_email'));
			$userIdEmail = preg_match('/^[A-z0-9_\-]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z.]{2,4}$/', $userid_email);
			$data = array();
			if($userIdEmail){
				$data = array('first_name, user_id, original_password, email');
				$where = array('email' => $userid_email);
			}else{
				$data = array('first_name, user_id, original_password, email');
				$where = array('user_id' => $userid_email);
			}
			$dataArr = $this->application_model->select($data, 'players', $where);
			if(count($dataArr) > 0) {
				$dataArr = $dataArr[0];
				#Send mail
				$header = 'Password';
				$subject = "LTAT Membership - Password Recover Detail";
				$mailBody = '<div style="border-color:#376213; border:solid 1px; padding: 5%; "><p><center><img width="60%" src="'.base_url('assets/images/header_01.jpg').'"/></center> </p>';
				$mailBody .= '<center><h3>Your LTAT Account Password Recovery Detail</h3></center>';
				$mailBody .= "<p>Dear ". ucwords($dataArr['first_name']) ."</p>";
				$mailBody .= '<p>You have successfully retrive your password for LTAT membership and now have access to the LTAT online service. Your membership detail appear below</p>';
				$mailBody .= '
					<table>
						<tr>
							<td>User Id :</td>
							<td>'. $dataArr['user_id'] .'</td>
						</tr>
						<tr>
							<td>Password :</td>
							<td>'. $dataArr['original_password'] .'</td>
						</tr>
					</table>';
				$mailBody .= '<br /><br />login here '.base_url("login");
				$mailBody .= '<p>Regards<br />LTAT Registration Team</p>';
				$mailBody .= '</div>';
				$mailSend = $this->commonfunctions->sendMail($dataArr['email'], $subject, $mailBody, $header);
				$this->commonfunctions->setFlashMessage('Password is sent to your registered email!', 'success');
				redirect('login', 'refresh');
				}
		}
	}
	
	#Check username for password reset already exists or not
	public function checkUsernameOREmail() {
		#Grab user input.
		$userid_email = $this->security->xss_clean($this->input->get('userid_email'));
		$userIdEmail = preg_match('/^[A-z0-9_\-]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z.]{2,4}$/', $userid_email);
		$data = array();
		if($userIdEmail){
			$data = array('email');
			$where = array('email' => $userid_email);
		}else{
			$data = array('user_id');
			$where = array('user_id' => $userid_email);
		}
		$dataArr = $this->application_model->select($data, 'players', $where);
		if(count($dataArr) > 0) {
			echo 'true';
		} else {
			echo 'false';
		}
	}
	
}
/* End of login.php file */
/* location: application/modules/admin/login.php */
/* Omit PHP closing tags to help vaoid accidental output */