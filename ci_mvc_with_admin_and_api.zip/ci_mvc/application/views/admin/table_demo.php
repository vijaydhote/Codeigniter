<div class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header d-block">
                        <h3>Vendor List</h3>
                    </div>
                    <div class="card-body">
                        <div class="dt-responsive">
                            <table id="simpletable"
                                   class="table table-striped table-bordered nowrap">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Vendor Name</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Contact Person Name</th>
                                    <th>Mobile Number</th>
                                </tr>
                                </thead>
                                <tbody>
                               <?php
                                if(!empty($vendors))
                                {
                                    $i = 1;
                                    foreach($vendors as $vendor)
                                    {
                                        //echo "<pre>"; print_r($vendor); die;
                                        ?>
                                        <tr>
                                            <td><?php echo $i;?></td>
                                            <td><?php echo ucwords($vendor['first_name'].' '.$vendor['last_name']);?></td>
                                            <td><?php echo ucwords($vendor['username']);?></td>
                                            <td><?php echo $vendor['email'];?></td>
                                            <td><?php echo ucwords($vendor['address']);?></td>
                                            <td><?php echo ucwords($vendor['contact_person']);?></td>
                                            <td><?php echo ucwords($vendor['mobile_number']);?></td>
                                        </tr>
                                        <?php 
                                    $i++;}
                                }

                               ?> 
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Vendor Name</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Contact Person Name</th>
                                    <th>Mobile Number</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>