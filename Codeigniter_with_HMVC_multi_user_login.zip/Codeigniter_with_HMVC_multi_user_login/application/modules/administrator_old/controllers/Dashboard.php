<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    private $administrator;
	public function __construct() {
		parent::__construct();
		#Check administrator login.
		$this->isAdministrator();
		$this->administrator = $this->session->userdata('administrator');
		$this->load->model('application_model');//Load application model
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button>', '</div>');
	}
	
	#Load administrator home page.
	public function index()
	{
		#title
		$data['title'] = 'Welcome Procurement Systems | Administrator';
        $data['administrator'] = $this->administrator;
		$data['page_content'] = 'administrator/dashboard';
		#Load view template.
		//$this->load->view('administrator/includes/header', $data);
		$this->load->view('administrator/administrator_template', $data);
		//$this->load->view('administrator/includes/footer');
	}

	#Load administrator home page.
	public function vendor()
	{
		#title
		$data['title'] = 'Welcome Procurement Systems | Vendor';
        $data['administrator'] = $this->administrator;
		$data['page_content'] = 'administrator/vendor';
		#Load view template.
		//$this->load->view('administrator/includes/header', $data);
		$this->load->view('administrator/administrator_template', $data);
		//$this->load->view('administrator/includes/footer');
	}
	
	#Logout administrator.
	public function logout() {
		$administrator = $this->session->userdata('administrator');
		if(!empty($administrator) && $administrator['type'] == 'Administrator') {
			$this->session->unset_userdata('administrator');
			redirect('administrator', 'refresh');
		}
	}

}
/* End of Dashboard.php file */
/* location: application/view/Dashboard.php */
/* Omit PHP closing tags to help vaoid accidental output */