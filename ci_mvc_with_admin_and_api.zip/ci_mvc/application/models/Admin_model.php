<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model
{
	#Define varaiables.
	private $result = '';
	private $query = '';
	
	public function __construct() {
		parent::__construct();
	}
	
	#Select plan query.
	public function selectQuery($query) {
		$result_query = $this->db->query($query)->result_array();
		return $result_query;
	}
	
	
}//End of class.

/* End of application_model.php file */
/* location: application/models/application_model.php */
/* Omit PHP closing tags to help vaoid accidental output */