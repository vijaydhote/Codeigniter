<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    private $admin;
	public function __construct() {
		parent::__construct();
		#Check administrator login.
		$this->isAdmin();
		$this->admin = $this->session->userdata('admin');
		$this->load->model('admin_model');//Load application model
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button>', '</div>');
	}
	
	#Load administrator home page.
	public function index()
	{
		#title
		$data['title'] = 'Welcome | Admin';
        $data['admin'] = $this->admin;
		$data['page_content'] = 'admin/dashboard';
		#Load view template.
		//$this->load->view('administrator/includes/header', $data);
		$this->load->view('admin/admin_template', $data);
		//$this->load->view('administrator/includes/footer');
	}

	#Load administrator home page.
	public function tableDemo()
	{
		#title
		$data['title'] = 'Welcome | Vendor';
        $data['admin'] = $this->admin;
		$data['page_content'] = 'admin/table_demo';
		$data['vendors'] = $this->admin_model->selectQuery("select * from tbl_users where is_deleted = '0' and type= 'Vendor' order by id DESC ");
		#Load view template.
		//$this->load->view('administrator/includes/header', $data);
		$this->load->view('admin/admin_template', $data);
		//$this->load->view('administrator/includes/footer');
	}

	#Logout administrator.
	public function logout() {

		//echo "<pre>"; print_r($this->session->userdata()); die;
		$admin = $this->session->userdata('admin');
		if(!empty($admin) && $admin['type'] == 'Admin') {
			$this->session->unset_userdata('admin');
			redirect('admin', 'refresh');
		}
	}
}
/* End of Dashboard.php file */
/* location: application/view/Dashboard.php */
/* Omit PHP closing tags to help vaoid accidental output */