<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Commonfunctions {
	
	#Define variables.
	private $result = '';
	private $ci = '';
	
	public function __construct() {
		$this->ci =& get_instance();
        //$this->ci->load->model('application_model');
	}
	
	#Password encryption.
	public function password($password) {
		$hash = '@cEG&*';
		$password = $hash.$password.$hash;
		
		// To password protect mysql injection.
		$password = stripslashes($password);
		//$password = mysql_real_escape_string($password);
		$password = base64_encode($password);
		$password = md5(serialize($password));
		return $password;
	}
	
	#Generate a unique id.
	public function getUniqueId() {
		return round(microtime(true));
	}
	
	#Set flash message
	public function setFlashMessage($msg='', $msgClass='success')
	{
		$this->ci->session->set_userdata('flash_message', '<div class="alert alert-'.$msgClass.'"><button type="button" class="close" data-dismiss="alert">×</button>'.$msg.'</div>');    
	}
	
	#Get/Display flash message
	public function getFlashMessage()
	{
		$flashMsg = $this->ci->session->userdata('flash_message');
		if($flashMsg)
		{
			echo $flashMsg;
		}
		$this->ci->session->unset_userdata('flash_message');
	}
	
	#Send mail for players.
	public function sendMail($email, $subject, $message, $header='', $cc='', $attatch1='', $attatch2='', $attatch3='', $attatchPdf='') {
		$config = Array(
			'protocol' => 'SMTP',
			'smtp_host' => 'md-40.webhostbox.net',
			'smtp_port' => 465,
			'smtp_user' => 'ltat@sportswiz.asia', 
			'smtp_pass' => 'Zy]p8aIo-&+I',
			'mailtype' => 'html',
			'charset' => 'iso-8859-1',
			'wordwrap' => TRUE
		);
		
		$this->ci->load->library('email', $config);
		$this->ci->email->set_newline("\r\n");
		$this->ci->email->from('ltat@sportswiz.asia', 'LTAT '.$header);
		$this->ci->email->to($email);
		$this->ci->email->cc($cc);
		$this->ci->email->subject($subject);
		if($attatch2 != ''){
			$this->ci->email->attach($attatch2);
		}
		if($attatch1 != ''){
			$this->ci->email->attach($attatch1);
		}
		if($attatch3 != ''){
			$this->ci->email->attach($attatch3);
		}
		if($attatchPdf != ''){
			$this->ci->email->attach($attatchPdf);
		}
		
		$this->ci->email->message($message);
		if($this->ci->email->send()){
			return 'true';
		} else {
			show_error($this->email->print_debugger());  
		}
	}
	
	#Encode string
	public function encodeString($string) {
		$string = stripcslashes($string);
		$string = base64_encode($string);
		return $string;
	}
	
	#Decode string
	public function decodeString($string) {
		$string = stripcslashes($string);
		$string = base64_decode($string);
		return $string;
	}
	
	#Set values
	public function setValues($values, $default='') {
		if(isset($values) && !empty($values)) {
			return $values;
		}
		return $default;
	}
	/*
	*	Get age of a person in year time
	*/
	public function getAge($dob, $tDate='') {
		if(!empty($dob)){
			$birthdate = new DateTime($dob);
			$today   = new DateTime('today');
			$age = $birthdate->diff($today)->y;
            //$age = $birthdate->diff($today)->format('%y years %m month %d day');
			return $age;
		}else{
			return 0;
		}
	}
	
	/*
    *   Get current week dates.
    */
	public function getCurrentWeekDates($day='monday'){
		$output = array();
		$startDate = date('Y-m-d', strtotime("$day this week"));
		$output[] = $startDate;
		for($i=1;$i<7;$i++){
			$output[$i] = date('Y-m-d', strtotime("$startDate +$i days"));
		}
		return $output;
	}
    
    /*
    *   Get age of a person according to last monday.
    */	
    public function getLastMonday($date=0) {
        if(!empty($date)) { //Get specific date(week) of monday.
            $days = date('N', strtotime($date));
            if($days == 1) {
                return date('Y-m-d', strtotime($date));
            } else {
                $days = $days - 1;
                return date('Y-m-d', strtotime('-'. $days .' day', strtotime($date)));
            }
        } else {
            if((date('N', time())) == 1) {
                return date('Y-m-d');
            } else {
                return date('Y-m-d', strtotime('last monday'));
            }
        }
    }
	
	/**
    * Get an array of \DateTime objects for each day (specified) in a year and month
    **/
    function getAllDaysInAMonth($year, $month, $day = 'Monday', $daysError = 3) {
        $dateString = 'first '.$day.' of '.$year.'-'.$month;

        if (!strtotime($dateString)) {
            throw new \Exception('"'.$dateString.'" is not a valid strtotime');
        }

        $startDay = new \DateTime($dateString);

        if ($startDay->format('j') > $daysError) {
            $startDay->modify('- 7 days');
        }

        $days = array();
        while ($startDay->format('Y-m') <= $year.'-'.str_pad($month, 2, 0, STR_PAD_LEFT)) {
            $days[] = clone($startDay);
            $startDay->modify('+ 7 days');
        }
        return $days;
    }
	
	function getMondays($year, $month){
		$mondays = array();
		# First weekday in specified month: 1 = monday, 7 = sunday
		$firstDay = date('N', mktime(0, 0, 0, $month, 1, $year));
		/* Add 0 days if monday ... 6 days if tuesday, 1 day if sunday
			to get the first monday in month */
		$addDays = (8 - $firstDay);#37; 7;
		$mondays[] = date('d M Y', mktime(0, 0, 0, $month, 1 + $addDays, $year));
	
		$nextMonth = mktime(0, 0, 0, $month + 1, 1, $year);
	
		# Just add 7 days per iteration to get the date of the subsequent week
		for ($week = 1, $time = mktime(0, 0, 0, $month, 1 + $addDays + $week * 7, $year);
			$time < $nextMonth;
			++$week, $time = mktime(0, 0, 0, $month, 1 + $addDays + $week * 7, $year)){
			$mondays[] = date('d M Y', $time);
		}
		return $mondays;
	} 
	
	/*
	* Sort array according to there numberic values.
	*/
	public function sortArrayNumeric($category = array()) {
		$data = array();
		$temp = array();
		$result = array();
		if(!empty($category)) {
			foreach($category as $rows){
				if(is_numeric($rows['category_age'])) {
					$data[] = array('category_age'=>$rows['category_age'], 'category_name'=>$rows['category_name'], 'id'=>$rows['id']);
				} else {
					$temp[] = array('category_age'=>$rows['category_age'], 'category_name'=>$rows['category_name'], 'id'=>$rows['id']);
				}
			}			
			asort($data);
			$result = (array_merge($data, $temp));
		}
		return $result;
	}
	
	/*
	* Get player category according to there dob.
	*/
	public function getPlayerCategory($category=array(), $dobYear, $gender){
		$result = '';
		if(!empty($category)) {
			foreach($category as $rows) {
				if($dobYear <= $rows['category_age']) {
					$result = $rows['id'];
					break;
				} else {
					if($rows['category_age'] == $gender) {
						$result = $gender;
						break;
					} else {
						$result = 0;
					}
				}
			}
		}
		return $result;
	}
	
	/**
	* Build a tree(parent childe relation).
	*/
	public function buildTree(array $elements, $parentId = 0) {
		$branch = array();
	
		foreach ($elements as $element) {
			if ($element['parent_id'] == $parentId) {
				$children = $this->buildTree($elements, $element['id']);
				if ($children) {
					$element['children'] = $children;
				}
				$branch[$element['id']] = $element;
				unset($elements[$element['id']]);
			}
		}
		return $branch;
	}
	
	/*
	*	@Get tournaments player category names.
	*/
	public function getPlayerCategoryNames($catIds=0) {
		$result = array();
		if(!empty($catIds)) {
			$query = "SELECT id, category_name FROM tbl_players_category WHERE id in (". $catIds .") AND is_deleted='0'";
			$stmt = $this->ci->db->prepare($query);
			$stmt->execute();
			$catData = $stmt->fetchAll();
			foreach($catData as $rows){
				$result[$rows['id']] = $rows['category_name'];
			}
		}
		return $result;
	}
    
    /*
	*	@date : change date
	*/
    public function changeDate($date, $format='Y-m-d') {
        $output = '';
        if(isset($date) && strtotime($date) > 0) {
            return date($format, strtotime($date));
        } else {
            return $output;
        }
    }
    
    /*
    * @get dashboard count data.
    */
    public function getDashboardCount($type='', $loginId=0){
        if(empty($loginId)) {
            $tournamentData = $this->ci->application_model->select(array('*'), 'tournaments', array('is_deleted'=>0), 0, 'all');
        } else {
            $tournamentData = $this->ci->application_model->select(array('*'), 'tournaments', array('is_deleted'=>0, 'created_by'=>$loginId), 0, 'all');
        }
        $data = array(
            'tournament_total' => 0,
            'tournament_approved' => 0,
            'tournament_launched' => 0
        );
        foreach($tournamentData as $rows) {
            $data['tournament_total'] = $data['tournament_total'] + 1;
            if($rows['status'] == 1 && $rows['is_launch'] == 0) {
                $data['tournament_approved'] = $data['tournament_approved'] + 1;
            } if($rows['status'] == 1 && $rows['is_launch'] == 1) {
                $data['tournament_launched'] = $data['tournament_launched'] + 1;
            }
        }
        return $data;
    }
}

/* End of Commonfunctions.php file */
/* location: application/libraries/Commonfunctions.php */
/* Omit PHP closing tags to help vaoid accidental output */